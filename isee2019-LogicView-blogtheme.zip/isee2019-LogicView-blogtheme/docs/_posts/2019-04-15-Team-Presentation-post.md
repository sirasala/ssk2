---
layout: post
title: "ISEE 2019 -- Team Presentation"
date: 2019-04-15
excerpt: "In this blog post we will introduce our Team, Project and our motivations towards taking course of “Introduction to software engineering for engineers”.	"
image: "/images/pic02.jpg"
---
## LogicView :

![team logo]({{site.baseurl}}/images/Team_Logo_v3.png " Logo of the team")

Welcome to our blog ‘LogicView’, here in this blog you can join us in journey to building an android application which makes spending, budgeting and saving money easy and trackable.

In this blog post we will introduce our Team, Project and our motivations towards taking course of “Introduction to software engineering for engineers”.	

## About the project :

The project we have selected to work on is ‘Money Control’ android application. Money management is a key aspect for every person. Money tracking is a plan that helps you prioritize your spending. With a track of your spending, you can move focus your money on the things that are most important to you, so we choose to develope an application that can help you in money management efficiently.
image

<span align="center">
![goal]({{site.baseurl}}/images/goal.jpg " goal"){:height="80%" width="80%"}
</span>
## The CASHTRACK application

![app]({{site.baseurl}}/images/applogo.jpg " Logo of the app"){:height="20%" width="20%"}

**GOALS**: We set some goals for our project that includes budget planning (of course everyone has different income, priorities etc) so these things will be input by the customer, then we will crunch the numbers (according to spending habits etc) and provide the user with their individual history, perhaps the future outlook and a few tips and advices, and we will present them visually (because we know honestly, numbers are boring ). 

![aim]({{site.baseurl}}/images/aim.jpg " aim of app"){:height="40%" width="40%"}

## Team members and their Motivation :

* **Sirasala Shiva Kumar** : I’m an Automobile Engineer, I’m eager to experience application development and create my own. This course ISEE will be my first step towards hands-on experience on development and coding.

* **Muhammad Mehran Sunny**: I always been interested in Android application. I believe that devices like smartphones, when used in a positive way can greatly affect our lives in a transformative way.

* **Ganapathi Bharat**     : I’m an Aerospace Engineer and extremely passionate about Industrial Automation and robotics. I want to develop programming skills through ISEE.

* **Danish Murad**         : I’m an Electronics Engineer but I’m really passionate about Computer Science pushing the capabilities of computers. I’m interested in Internet of Things and networked devices. I know a little bit of C++ but I wanted to learn JAVA and software project management.
 
## Roles and Responsibilities : 

When we set out to assign roles there was a unanimous agreement that roles should be loosely assigned and shouldn’t be rigid. The idea is not only to make use of everyone’s skillset as efficiently as possible, but also to have enough flexibility so that everyone contributes to the project in one way or another. 

![roles]({{site.baseurl}}/images/roles.jpg " roles of team")

All four of us will work accordingly together for successfully working android application for the given requirements of the customer. 

##	Complimentary skills :

All four of us come from different backgrounds so it’s important all voices are heard and the ideas are given a good thought and everyone is open to communication and accept healthy criticism.

The skills of our team members are diverse like management skills, creative ideas, problem solving, analytical skills and programming skills. All of these would help us in completing a software engineering project successfully.

##	Communication :

The key to any kind of project is effective communication. And this does not only mean internal communication within the team, but also with the customer. If you don’t understand the requirements correctly you’ve already failed at the first hurdle. So to make sure everyone is on the same page, we set up a few channels.

We will use WhatsApp and Facebook messenger for communication and will have weekly team meetings. For collaboration, sharing and updating we use GITHUB, ZENHUB for managing and planning the project.

<span align="center">
![communication]({{site.baseurl}}/images/comm.jpg " communication"){:height="30%" width="30%"}
</span>
## Flexibility :

We are focused in designing the team not the job this gives you a much greater degree of flexibility about how you can knit together different working patterns and styles. So we believe we can adopt to the changes.

<span align="center">
![flexi]({{site.baseurl}}/images/flexi.jpg " flexi")
</span>
