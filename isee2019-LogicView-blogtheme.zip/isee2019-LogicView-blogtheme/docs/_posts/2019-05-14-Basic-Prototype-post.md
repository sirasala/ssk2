---
layout: post 
title: "ISEE 2019 -- Basic Prototype" 
date: 2019-05-14
excerpt: "In this blog post we will introduce our first prototype."
image: "/images/pic02.jpg"
---

## Basic Prototype

This blog is on the basic prototype of the application. After analyzing the requirements given and system design, we create a basic prototype of the UI design focusing on the user’s need. The link for downloading the apk file is below.

https://github.com/DBSE-teaching/isee2019-LogicView/blob/release/app-debug.apk

Bellow are some screen shots of the application.

![bp]({{site.baseurl}}/images/Prototype_MainScreen1.PNG "bp") Fig[1]

The above screenshot is the main screen of the application Castrack having the Income, Expenses, NET amount left and a pie diagram for reprsenting the expenses.

![bp]({{site.baseurl}}/images/Prototype_MainScreen2.PNG "bp") Fig[2]              ![bp]({{site.baseurl}}/images/Prototype_MainScreen3.PNG "bp") Fig[3]


The Figure[2] sceenshot shows the Activity log option and Figure[3] shows the buttons to add the expense and income 


![bp]({{site.baseurl}}/images/Prototype_ActivityScreen_1.PNG "bp") Fig[4]

Above Figure[4] represents the activity of adding the expenses

![bp]({{site.baseurl}}/images/Prototype_ActivityScreen_2.PNG "bp")Fig[5] ![bp]({{site.baseurl}}/images/Prototype_ActivityScreen_3.PNG "bp")Fig[6]  ![bp]({{site.baseurl}}/images/Prototype_ActivityScreen_4.PNG "bp")Fig[7]


The Figures [5], [6] and [7] shows the options for adding the expenses data.
 
 
 Soon we will be back with the modified prototype that is fully functional.

