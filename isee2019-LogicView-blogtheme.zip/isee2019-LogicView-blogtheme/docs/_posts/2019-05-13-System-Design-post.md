---
layout: post 
title: "ISEE 2019 -- System Design" 
date: 2019-05-13
excerpt: "In this blog post we will discuss about the class diagrams and system design.	"
image: "/images/pic02.jpg"
---
## System Design :

In this blog our team will give information about the Class diagrams, activity diagrams, sequence diagrams and development strategy. Before developing an application the first step is to analyze requirements then come the next step i.e. the creation of the Class UML diagram , activity diagrams etc based on these diagrams the application back end coding is done and makes the process of the application understandable to customer and every team member.

The system design process is nothing but to meet the expectations of the customer by designing the perfect architecture, modules, interfaces, and data. In this stage we will be adapting one design pattern in development stages. The active development strategy of our team is being defined in this blog. Our third blog is all about the plan for coding the application.

## Class Diagram :

![rs]({{site.baseurl}}/images/p1s.png "rs")

**Class Attributes**

![rs]({{site.baseurl}}/images/p2s.png "rs")

**Class Methods**

![rs]({{site.baseurl}}/images/p3s.png "rs")

## Behavioural and Activity Diagram :
Behavioural diagram for the cashtrack mony control application.
![rs]({{site.baseurl}}/images/p4s.png "rs")

**Activity diagram for use case “Entering the amount spent”**

![rs]({{site.baseurl}}/images/p5s.png "rs")

**Activity diagram for use case “Viewing data”**

![rs]({{site.baseurl}}/images/p6s.png "rs")

## Development Strategies

We started with the programming of the application once we were completed with the UML Class diagrams , Behavioral diagram, Activity diagrams. From the right start of this project we believed in divide and rule method, we divide the work among each other and successfully completed the assigned tasks. First we gathered the requirements, then analyzed them , created class diagrams figured out the attributes and we are know working on the prototype .The basis prototype is ready.


We looked over the work of each other by having close contact. Apart from that we had weekly two team meetings and figuring out the tasks for each other for the future weeks . We used Trello to manage and monitor our work. We added more team meetings according to the deadlines and the workload. For updating, maintaining clarity with other team members about the assigned tasks and moving the user stories to the dashboard we are using trello. After using trello for few weeks we think that this approach works out perfectly for our team.


![rs]({{site.baseurl}}/images/devstra.PNG "rs"){:height="100%" width="100%"}

That's all for this blog, in the next blog we will show our first prototype of the application which consists of the basic functions.

Stay Tuned!

