Team Status Report

------------

1.	Last Week’s Goals

    •	More coding and development for the application

    •	Further work to implement the requirements given by customer

    •	Finalize the way forward and strategy with 3 team members
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application  
          
          o	Shiva: Blog Writing and Team communication
       
------------

2.	This Week’s Progress

    •	Worked on the Adding Transaction and Categorisation activities.
    
    •	Worked on the GUI of the application. 
    
    •	Worked on integrating of the data with SQLite 
    
    •	Worked on the email integration of the app so that reports can be sent via email  
        
    •	Working on the team presentation and Blog for the next milestone
    
------------

3.	Plans and Goals for Next Week

    •	More coding and development for the application

    •	Further work to integrate the data with SQLite
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application  
          
          o	Shiva: Blog Writing and Team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	Feedback about current progress on development of application
    
    •	Discussion on advanced prototype and requirements for the next milestone
    
    •	Expectation about next week’s progress


