Team Status Report

------------

1.	Last Week’s Goals

    •	More coding and development for the application

    •	Further work to implement the new requirement given by customer

    •	Finalization of the prototype and requirements
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application
          
          o	Bharat: Coding for the backend of the application  
          
          o	Shiva: Blog Writing and team communication
       
------------

2.	This Week’s Progress

    •	Meeting of the team to reassign roles after leaving of 4th Team Member
    
    •	Coding and development of the application 
    
    •	Worked on the GUI of the of the application 
    
    •	Worked on the email integration of the app so that reports can be sent via email  
        
    •	Working on the team presentation and Blog for the next milestone
    
------------

3.	Plans and Goals for Next Week

    •	More coding and development for the application

    •	Further work to implement the requirements given by customer

    •	Finalize the way forward and strategy with 3 team members
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application  
          
          o	Shiva: Blog Writing and Team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	Feedback about current progress on development of application
    
    •	Discussion on advanced prototype
    
    •	Expectation about next week’s progress

