Team Status Report

------------

1.	Last Week’s Goals

    •	Analysis of User Requirement.

    •	Build the basic structure of the application, on which we will later add functionalities.

    •	Responsibilities assigned to each group member:
    
          o	Danish: Blog Writing and Coordination with the User
          
          o	Mehran: Focus on the development of the application
          
          o	Bharat: Construct the basic structure of the application
          
          o	Shiva: Team Status reports and overall team communication
       
------------

2.	This Week’s Progress

    •	Coordinated with the user/TA and got their requirements.   
    
    •	Analyzed and discussed the user requirements and how we can incorporate them into our app.
    
    •	Discussed and came up with the User Stories. 
    
    •	Worked on the basic structure of the application. 
    
    •	Started working on the blog for the next milestone.
    
    •	Started working on the basic GUI setup of the application. 
    
------------

3.	Plans and Goals for Next Week

    •	Further Analysis of User Requirement.

    •	Further work on the basic structure of the application. 

    •	Agree on a unified GUI view.
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and backend development
          
          o	Mehran: Focus on the development of the backend
          
          o	Bharat: Construct the basic GUI of the application
          
          o	Shiva: Next Week's Team Status report and overall team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	User Stories 
    
    •	Discussion about the GUI
    
    •	Discuss the basic architecture of the application
    
    •	Discuss difficulties in the analysis of the requirements
    
    •	Expectation about next week’s progress
