Team Status Report

------------

1.	Last Week’s Goals

    •	Further Analysis of User Requirement.

    •	Further work on the UML diagram structure of the application. 

    •	Finalization of our UML diagram and then start coding on it.
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and UML diagram
          
          o	Mehran: Construct the UML diagram and then development of application
          
          o	Bharat: Next Week's team presentation  
          
          o	Shiva: Next Week's blog writing and overall team communication
       
------------

2.	This Week’s Progress

    •	Meeting of the team to finalize UML Diagram and Class Diagram
    
    •	Coding and development for the protype 
    
    •	Discussed the basic GUI of the application 
    
    •	Clarified a few problems with GITHUB  
    
    •	Finalize and incorporate the application logo
    
    •	Started working on the team presentation and Blog for the next milestone
    
------------

3.	Plans and Goals for Next Week

    •	More coding and development for the Prototype

    •	Further work on the UML diagram and class structure of the application 

    •	Finalization of the prototype
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application
          
          o	Bharat: Coding for the backend of the application  
          
          o	Shiva: Next Week's Blog Writing and preparation for the presentation
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	Feedback about UML and Class Diagram 
    
    •	Discussion about using GITHUB and its branches
    
    •	Discussion about the Prototype
    
    •	Clarifications about the customer requirements (recurring/nonrecurring and categorisation) 
    
    •	Expectation about next week’s progress
