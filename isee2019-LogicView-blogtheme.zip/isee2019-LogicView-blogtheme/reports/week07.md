Team Status Report

------------

1.	Last Week’s Goals

    •	Complete UML Class Diagram

    •	Complete Sequence Diagram for application 

    •	Complete activity diagram and basic prototype of application
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application
          
          o	Bharat: Coding for the backend of the application  
          
          o	Shiva: This Week's Blog Writing and preparation for the presentation
       
------------

2.	This Week’s Progress

    •	Meeting of the team to focus on the new requirement givem by the customer
    
    •	Coding and development of the application 
    
    •	Discussed the  GUI of the application 
    
    •	Clarified a few problems with GITHUB  
    
    •	Finalize and incorporate the logos for categories
    
    •	Started working on the team presentation and Blog for the next milestone
    
------------

3.	Plans and Goals for Next Week

    •	More coding and development for the application

    •	Further work to implement the new requirement given by customer

    •	Finalization of the prototype and requirements
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and User Interface
          
          o	Mehran: Coding for the backend of the application
          
          o	Bharat: Coding for the backend of the application  
          
          o	Shiva: Blog Writing and team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	Feedback about current progress on development of application
    
    •	Discussion about using GITHUB and its branches
    
    •	Discussion about the customer satisfaction 
    
    •	Expectation about next week’s progress
