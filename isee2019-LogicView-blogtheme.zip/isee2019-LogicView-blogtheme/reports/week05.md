Team Status Report

------------

1.	Last Week’s Goals

    •   Further Analysis of User Requirement.

    •	Further work on the basic structure of the application. 

    •	Agree on a unified GUI view.
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Structure of the use case and backend development
          
          o	Mehran: Focus on the development of the application and construct use case
          
          o	Bharat: Construct the basic GUI of the application
          
          o	Shiva: Overall team communication and gather user stories
       
------------

2.	This Week’s Progress

    •	Meeting of the team to finalze use case of application.   
    
    •	Analyzed how we can incorporate user requirement into our use case.
    
    •	Discussed the User Stories. 
    
    •	Worked on the basic structure of the application. 
    
    •	Started working on the presentation and blog for the next milestone.
    
    •	Started working on the UML diagram of the application. 
    
------------

3.	Plans and Goals for Next Week

    •	Further Analysis of User Requirement.

    •	Further work on the UML diagram structure of the application. 

    •	Finalization of our UML diagram and then start coding on it.
    
    •	Responsibilities assigned to each group member:
    
          o	Danish: Basic Structure of the application and UML diagram
          
          o	Mehran: Construct the UML diagram and then development of application
          
          o	Bharat: Next Week's team presentation  
          
          o	Shiva: Next Week's blog writing and overall team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	UML diagram 
    
    •	Discussion about the GUI
    
    •	Discuss the implementation of basic architecture of the application
    
    •	Discuss difficulties in the implementation of the requirements
    
    •	Expectation about next week’s progress
