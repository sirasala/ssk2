Team Status Report

------------

1.	Last Week’s Goals

    •	N/A
    

------------

2.	This Week’s Progress

    •	Initial Meeting to discuss the three topics of the project. 
    
    •	Agreed on the Money Control topic.
    
    •	Worked on the team logo and the application logo.
    
    •	Worked on the presentation.
    
    •	Worked together to understand GITHUB and its extensions.
    
    •	Set up the initial roles and responsibilities.
    
    •	Set up the initial communication channels.
    
------------

3.	Plans and Goals for Next Week

    •	Analysis of User Requirement.

    •	Build the basic structure of the application, on which we will later add functionalities.

    •	Responsibilities assigned to each group member:
    
          o	Danish: Blog Writing and Coordination with the User
          
          o	Mehran: Focus on the development of the application
          
          o	Bharat: Construct the basic structure of the application
          
          o	Shiva: Team Status reports and overall team communication
          
------------

4.	Agenda of the meeting with the Customer/TA

    •	User Requirements
    
    •	Application Features and Functionality
    
    •	Discuss the basic architecture of the application
    
    •	Feedback on Blog Formatting
    
    •	Expectation about next week’s progress
